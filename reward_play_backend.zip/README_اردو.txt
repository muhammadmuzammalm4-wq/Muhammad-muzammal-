# Reward Play — Backend

یہ backend آپ کی موجودہ `index.html` کے API endpoints کے مطابق بنایا گیا ہے۔

## فولڈر
- `server.js` — Login/Register، Game points، Daily Mission، Withdrawal API
- `package.json` — ضروری packages
- `public/index.html` — آپ کی موجودہ گیم

## مقامی طور پر چلانے کا طریقہ

Node.js انسٹال ہونے کے بعد:

```bash
npm install
npm start
```

پھر browser میں:

```text
http://localhost:3000
```

## ضروری سیکیورٹی
Production پر `JWT_SECRET` کو لازماً ایک لمبی، random secret value سے تبدیل کریں۔

مثال:
```bash
JWT_SECRET="اپنا-بہت-مضبوط-secret" npm start
```

## Withdrawal
Backend withdrawal request کو `pending` رکھتا ہے۔ اصل JazzCash/Easypaisa payment خودکار طور پر نہیں ہوتی؛ اس کے لیے الگ، مجاز payment integration اور merchant/account setup درکار ہوگا۔
