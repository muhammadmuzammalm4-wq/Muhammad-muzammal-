const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET";

const db = new Database("reward_play.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  last_mission TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  points INTEGER NOT NULL,
  account TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function tokenFor(user) {
  return jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "30d" });
}

function auth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) throw new Error();
    const payload = jwt.verify(header.slice(7), JWT_SECRET);
    req.user = db.prepare("SELECT id,name,phone,points FROM users WHERE id=?").get(payload.id);
    if (!req.user) throw new Error();
    next();
  } catch {
    res.status(401).json({ error: "براہِ کرم پہلے Login کریں۔" });
  }
}

app.post("/api/register", async (req, res) => {
  try {
    const { name, phone, password } = req.body;
    if (!name || !phone || !password || password.length < 6)
      return res.status(400).json({ error: "نام، موبائل اور کم از کم 6 حروف کا پاس ورڈ دیں۔" });

    const hash = await bcrypt.hash(password, 10);
    const result = db.prepare(
      "INSERT INTO users(name,phone,password_hash) VALUES(?,?,?)"
    ).run(name.trim(), phone.trim(), hash);

    const user = db.prepare("SELECT id,name,phone,points FROM users WHERE id=?").get(result.lastInsertRowid);
    res.json({ token: tokenFor(user), user });
  } catch {
    res.status(400).json({ error: "یہ موبائل نمبر پہلے سے رجسٹرڈ ہے یا معلومات درست نہیں۔" });
  }
});

app.post("/api/login", async (req, res) => {
  const { phone, password } = req.body;
  const row = db.prepare("SELECT * FROM users WHERE phone=?").get((phone || "").trim());
  if (!row || !(await bcrypt.compare(password || "", row.password_hash)))
    return res.status(401).json({ error: "موبائل نمبر یا پاس ورڈ غلط ہے۔" });

  const user = { id: row.id, name: row.name, phone: row.phone, points: row.points };
  res.json({ token: tokenFor(user), user });
});

app.get("/api/me", auth, (req, res) => res.json(req.user));

app.post("/api/game", auth, (req, res) => {
  const hits = Math.max(0, Math.min(1000, Number(req.body.hits) || 0));
  // Server-side reward rule: 1 hit = 1 point.
  db.prepare("UPDATE users SET points=points+? WHERE id=?").run(hits, req.user.id);
  res.json(db.prepare("SELECT id,name,phone,points FROM users WHERE id=?").get(req.user.id));
});

app.post("/api/mission", auth, (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if (user.last_mission === today)
    return res.status(400).json({ error: "آج کی Daily Mission پہلے ہی مکمل ہو چکی ہے۔" });

  db.prepare("UPDATE users SET points=points+100,last_mission=? WHERE id=?").run(today, req.user.id);
  res.json(db.prepare("SELECT id,name,phone,points FROM users WHERE id=?").get(req.user.id));
});

app.post("/api/withdraw", auth, (req, res) => {
  const points = Number(req.body.points);
  const account = String(req.body.account || "").trim();

  if (!Number.isInteger(points) || points < 500)
    return res.status(400).json({ error: "کم از کم 500 points withdrawal کے لیے درکار ہیں۔" });
  if (!account)
    return res.status(400).json({ error: "JazzCash/Easypaisa account درج کریں۔" });

  const tx = db.transaction(() => {
    const user = db.prepare("SELECT points FROM users WHERE id=?").get(req.user.id);
    if (user.points < points) throw new Error("آپ کے پاس اتنے points موجود نہیں ہیں۔");

    db.prepare("UPDATE users SET points=points-? WHERE id=?").run(points, req.user.id);
    db.prepare("INSERT INTO withdrawals(user_id,points,account) VALUES(?,?,?)")
      .run(req.user.id, points, account);
  });

  try {
    tx();
    res.json({ message: "Withdrawal request جمع ہو گئی ہے۔ Status: pending" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get("/api/withdrawals", auth, (req, res) => {
  res.json(db.prepare(
    "SELECT points,account,status,created_at FROM withdrawals WHERE user_id=? ORDER BY id DESC"
  ).all(req.user.id));
});

app.listen(PORT, () => console.log(`Reward Play running on port ${PORT}`));
